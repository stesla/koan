//
//  J3ProxySettings.h
//  J3Terminal
//
//  Created by Samuel on 1/1/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface J3ProxySettings : NSObject 
{
  NSDictionary * proxyDictionary;
}

+ (J3ProxySettings *) settingsWithHostname:(NSString *)hostname
                                      port:(int)port
                                   version:(int)version
                                  username:(NSString *)username
                                  password:(NSString *)password;

// Designated initializer
- (id) initWithHostname:(NSString *)hostname
                   port:(int)port
                version:(int)version
               username:(NSString *)username
               password:(NSString *)password;

- (NSDictionary *)dictionary;

- (NSString *) hostname;
- (int) port;
- (int) version;
- (NSString *) username;
- (NSString *) password;
@end
