//
// J3TelnetConnection.h
//
// Copyright (C) 2004 3James Software
//
// J3Terminal is free software; you can redistribute it and/or modify it under
// the terms of version 2.1 of the GNU Lesser General Public License as
// published by the Free Software Foundation.
//
// J3Terminal is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// J3Terminal; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA
//

#import <Cocoa/Cocoa.h>
#import <J3Terminal/J3Stream.h>
#import <J3Terminal/J3InputStream.h>

typedef enum J3ConnectionStatus
{
  J3ConnectionStatusNotConnected,
  J3ConnectionStatusConnecting,
  J3ConnectionStatusConnected,
  J3ConnectionStatusClosed,
} J3ConnectionStatus;

typedef enum J3ConnectionClosedReason
{
  J3ConnectionClosedReasonNotClosed,
  J3ConnectionClosedReasonClient,
  J3ConnectionClosedReasonServer,
  J3ConnectionClosedReasonError
} J3ConnectionClosedReason;

enum J3TelnetCommands
{
  TEL_SE   = 240,
  TEL_NOP  = 241,
  TEL_DM   = 242,
  TEL_BRK  = 243,
  TEL_IP   = 244,
  TEL_AO   = 245,
  TEL_AYT  = 246,
  TEL_EC   = 247,
  TEL_EL   = 248,
  TEL_GA   = 249,
  TEL_SB   = 250,
  TEL_WILL = 251,
  TEL_WONT = 252,
  TEL_DO   = 253,
  TEL_DONT = 254,
  TEL_IAC  = 255,
  TEL_NONE = 256
};

#define MUTelnetBufferMax 1024

@interface J3TelnetConnection : NSObject
{
  J3InputStream *inputStream;
  J3Stream *outputStream;
  NSMutableData *readBuffer;
  NSMutableData *writeBuffer;
  NSString *errorMessage;
  J3ConnectionStatus connectionStatus;
  J3ConnectionClosedReason reasonClosed;
  BOOL canWrite;
  BOOL isInCommand;
  int commandChar;
  id delegate;
}

// Designated initializer
- (id) initWithInputStream:(J3InputStream *)input  
              outputStream:(J3Stream *)output;

- (id) initWithHostName:(NSString *)hostName 
             onPort:(int)port;

// Getters
- (id) delegate;
- (J3InputStream *) input;
- (NSString *) errorMessage;
- (J3Stream *) output;

// Setters
- (void) setDelegate:(id)delegate;
- (void) setInput:(J3InputStream *)input;
- (void) setOutput:(J3Stream *)output;

// Connecting
- (void) open;
- (void) close;

- (BOOL) enableProxyWithHostname:(NSString *)hostname
                          onPort:(int)port
                         version:(int)version
                        username:(NSString *)username
                        password:(NSString *)password;

- (BOOL) setSecurityLevel:(NSString *)level;

// State Flags
- (BOOL) isConnected;
- (BOOL) isError;
- (BOOL) isInCommand;

- (J3ConnectionStatus) connectionStatus;
- (J3ConnectionClosedReason) reasonClosed;

// IO
- (NSString *) read;
- (void) writeData:(NSData *)data;
- (void) writeString:(NSString *)string;
- (void) writeLine:(NSString *)string;

- (BOOL) sendLine:(NSString *)string;
@end

// Delegate Methods
@interface NSObject (J3TelnetConnectionDelegate)
- (void) telnetDidReadLine:(J3TelnetConnection *)telnet;
- (void) telnetDidChangeStatus:(J3TelnetConnection *)telnet;
@end
