//
//  J3Stream.h
//  J3Terminal
//
//  Created by Samuel on 12/18/04.
//  Copyright 2004 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface J3Stream : NSObject 
{
  NSStream * stream;
  id delegate;
}

+ (J3Stream *) streamWithStream:(NSStream *)aStream;

// Designated initializer
- (id) initWithStream:(NSStream *)aStream;

- (id) delegate;
- (void) setDelegate:(id)anObject;
- (NSStream *) stream;
- (NSStreamStatus) streamStatus;
- (void) setStream:(NSStream *)aStream;
- (void) scheduleInRunLoop:(NSRunLoop *)aRunLoop
                   forMode:(NSString *)aMode;
@end

// Delegate methods
@interface NSObject (J3StreamDelegate)
- (void) j3stream:(J3Stream *)j3stream handleEvent:(NSStreamEvent)event;
@end
