//
// J3Stream.h
//
// Copyright (C) 2004 3James Software
//
// J3Terminal is free software; you can redistribute it and/or modify it under
// the terms of version 2.1 of the GNU Lesser General Public License as
// published by the Free Software Foundation.
//
// J3Terminal is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// J3Terminal; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA
//

#import <Cocoa/Cocoa.h>

@interface J3Stream : NSObject 
{
  NSStream *stream;
  id delegate;
}

+ (J3Stream *) streamWithStream:(NSStream *)aStream;

// Designated initializer
- (id) initWithStream:(NSStream *)aStream;

- (id) delegate;
- (void) setDelegate:(id)anObject;
- (NSStream *) stream;
- (NSStreamStatus) streamStatus;
- (void) setStream:(NSStream *)aStream;
- (void) scheduleInRunLoop:(NSRunLoop *)aRunLoop
                   forMode:(NSString *)aMode;

- (id) propertyForKey:(NSString *)key;
- (BOOL) setProperty:(id)property forKey:(NSString *)key;
@end

// Delegate methods
@interface NSObject (J3StreamDelegate)
- (void) j3stream:(J3Stream *)j3stream handleEvent:(NSStreamEvent)event;
@end
