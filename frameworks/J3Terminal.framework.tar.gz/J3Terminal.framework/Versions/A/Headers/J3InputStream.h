//
// J3InputStream.h
//
// Copyright (C) 2004 3James Software
//
// J3Terminal is free software; you can redistribute it and/or modify it under
// the terms of version 2.1 of the GNU Lesser General Public License as
// published by the Free Software Foundation.
//
// J3Terminal is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// J3Terminal; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA
//

#import <Cocoa/Cocoa.h>
#import <J3Terminal/J3Stream.h>

@interface J3InputStream : J3Stream

// Constructors
+ (J3InputStream *) inputStreamWithStream:(NSStream *)stream;

// Accessors/Mutators
- (NSInputStream *) inputStream;

// NSInputStream forwards
- (int) read:(uint8_t *)buffer maxLength:(unsigned int)len;

@end
