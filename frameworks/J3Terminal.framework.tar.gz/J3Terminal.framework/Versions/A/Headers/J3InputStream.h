//
//  J3InputStream.h
//  J3Terminal
//
//  Created by Samuel on 12/20/04.
//  Copyright 2004 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <J3Terminal/J3Stream.h>

@interface J3InputStream : J3Stream
{
}

// Constructors
+ (J3InputStream *) inputStreamWithStream:(NSStream *)stream;

// Accessors/Mutators
- (NSInputStream *) inputStream;

// NSInputStream forwards
- (int) read:(uint8_t *)buffer maxLength:(unsigned int)len;

@end
